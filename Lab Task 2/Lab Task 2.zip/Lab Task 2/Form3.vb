﻿Public Class Form3

    Private Sub btSubmit_Click(sender As Object, e As EventArgs) Handles btSubmit.Click
        End
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
    End Sub

    Private Sub lbModel_Click(sender As Object, e As EventArgs) Handles lbModel.Click
    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class